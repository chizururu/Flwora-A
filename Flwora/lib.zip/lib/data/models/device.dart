class Device {
  final int id;
  final String name;
  final int sectorId;
  final String macAddress;
  final bool status;
  final int irrigationState;
  final bool aiStatus;

  // Constructor
  Device({
    required this.id,
    required this.name,
    required this.sectorId,
    required this.macAddress,
    required this.status,
    required this.irrigationState,
    required this.aiStatus,
  });

  factory Device.fromJson(Map<String, dynamic> json) => Device(
    id: json['id'],
    name: json['name'],
    sectorId: json['sector_id'],
    macAddress: json['mac_address'],
    status: json['status'] == 1,
    irrigationState: json['irrigation_state'] ?? 0,
    aiStatus: json['ai_status'] == 1,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'sector_id': sectorId,
    'mac_address': macAddress,
    'status': status ? 1 : 0,
    'irrigation_state': irrigationState,
    'ai_status': aiStatus ? 1 : 0,
  };
}
