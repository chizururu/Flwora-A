import 'package:flwora/data/domains/auth_repository.dart';

class AuthRepositoryImpl implements AuthRepository {}
