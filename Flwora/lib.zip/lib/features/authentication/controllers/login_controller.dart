import 'package:get/get.dart';

class LoginController extends GetxController {}
