import 'package:get/get.dart';

class RegisterController extends GetxController {}
