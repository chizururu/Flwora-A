import 'package:get/get.dart';

class DeviceRealtimeController extends GetxController {}