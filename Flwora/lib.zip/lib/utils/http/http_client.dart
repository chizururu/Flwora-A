class THttpClient {
  const THttpClient._();
}
