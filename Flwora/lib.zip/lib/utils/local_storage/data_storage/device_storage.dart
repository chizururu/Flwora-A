import 'package:flwora/data/models/device.dart';
import 'package:flwora/utils/local_storage/base_storage.dart';

class DeviceStorage extends BaseStorage<List<Device>> {}
