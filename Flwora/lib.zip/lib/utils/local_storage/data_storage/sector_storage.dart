import 'package:flwora/data/models/sector.dart';
import 'package:flwora/utils/local_storage/base_storage.dart';

class SectorStorage extends BaseStorage<List<Sector>> {}