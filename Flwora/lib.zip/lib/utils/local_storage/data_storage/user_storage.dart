import 'package:flwora/data/models/user.dart';
import 'package:flwora/utils/local_storage/base_storage.dart';

class UserStorage extends BaseStorage<User> {}
