import 'package:flutter/material.dart';
import 'package:flwora/utils/constants/colors.dart';
import 'package:google_fonts/google_fonts.dart';

class TTextTheme {
  TTextTheme._();
}
